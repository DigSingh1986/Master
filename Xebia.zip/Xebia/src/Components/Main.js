import React from 'react';
import Routes from '../Route';

function Main() {
  return (
	<div className="pagewrapper">
	<Routes />
	</div>
  );
}

export default Main;